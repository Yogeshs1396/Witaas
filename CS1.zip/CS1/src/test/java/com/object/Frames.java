package com.object;

import org.openqa.selenium.By;

public class Frames {
	
	public By SwitchTo= By.xpath("//a[@href='Frames.html']");
	public By input = By.xpath("//input[@type='text']");
	public By multipleF= By.xpath("//a[contains(text(),'Iframe with in an Iframe')]");


}

