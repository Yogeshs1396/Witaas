package com.object;

import org.openqa.selenium.By;

public class Selectable {

	public By Interaction = By.xpath("//a[@href='Interactions.html']");
	public By Selectable = By.xpath("//a[@href='Selectable.html']");
	public By Serialize=By.xpath("//a[contains(text(),'Serialize')]");
	public By CBtest=By.xpath("//ul[@class='SerializeFunc']/li[4]");
	public By Text= By.xpath("//p[@id='feedback']");

}
